import os
# import re
import time
import json
import pandas as pd
import logging
from tqdm import tqdm
from openai import OpenAI
import re
import openai
import asyncio

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

stream_handler = logging.StreamHandler()
logger.addHandler(stream_handler)
file_handler = logging.FileHandler(filename='./log/taxonomy_filter-ask-20241212.log')
logger.addHandler(file_handler)

### custom #################
# 문장의미 태깅 9종 category
SEMANTICS_CATEGORY = [
  "제안방법", "기술정의", "성능/효과", "후속연구", "이론/모형",
  "문제정의", "대상데이터", "데이터처리", "가설설정"
]

RESULT_DIR = 'result'
EXTRACT_DIR = 'extract'
FILTER_DIR = 'filter'

GPT_3_5_TURBO = "gpt-3.5-turbo"
GPT_4O = "gpt-4o"
GPT_4O_MINI = "gpt-4o-mini"

GPT_MODEL = GPT_4O#GPT_4O_MINI
api_key = "#Your Own Key#"
#api_key = os.environ.get('OPENAI_API_KEY')
client = OpenAI(api_key=api_key)

############################


def main():
  # prepare output directory
  os.makedirs(os.path.join(RESULT_DIR, FILTER_DIR), exist_ok=True)

  all_batch_run_list = create_all_batches()
  check_all_batches(all_batch_run_list)

def load_content_list(data_dir):
   contents = []

   for filename in os.listdir(data_dir):
      if filename.endswith('.json'):
        file_path = os.path.join(data_dir, filename)
        with open(file_path, 'r', encoding='utf-8') as f:
          content = f.read().strip()

          # Handle the specific format : {},{},...
          content = re.sub(r'\}\s*\{', '},{', content)
          # wrap with square bracket
          content = f'[{content}]'

          try:
            data = json.loads(content)
            # contents.append(data)
            # flatten the list
            contents.extend(data)
          except json.JSONDecodeError as e:
            print(f"Error parsing JSON in file {filename} : {e}")
            continue

   return contents

def create_all_batches():
  all_batch_run_list = list()
  ## RUNNING
  dir_path = "./data"

  ## load categories and articles
  logger.info(f'loading all JAKO....json ...')
  contents_list = load_content_list(dir_path)
  logger.info(f'all contents: {len(contents_list)} files')

  batch_run_list = create_batches(contents_list)
  logger.info(f'{len(batch_run_list)} batch runs created')
  logger.info(json.dumps(batch_run_list, indent=2, ensure_ascii=False))

  all_batch_run_list.extend(batch_run_list)

  ## SAVE file
  logger.info(f'saving all batch')

  # result category list having request_id
  save_json(contents_list, os.path.join(RESULT_DIR, FILTER_DIR, f'total_cateogrization-gpt4o-20241212.json'))

  logger.info(f'In total, {len(all_batch_run_list)} batch runs created')
  return all_batch_run_list


def create_batches(contents_list):
  # prepare batch file (.jsonl) from list of requests of the following format:
  # {"custom_id": "request-1", "method": "POST", "url": "/v1/chat/completions",
  #  "body": {"model": "gpt-3.5-turbo-0125", "messages": [{"role": "system", "content": "You are a helpful assistant."}, {"role": "user", "content": "Hello world!"}], "max_tokens": 1000}}

  batch_run_list = list()

  batch_count = 0
  request_count = 0
  request_list = list()
  request_id = 0
  for content in contents_list:
      request_id = batch_count * 5000 + request_count + 1
      sentence = content.get('sentence')
      tag = content.get('tag')
      if sentence is not None and tag is not None:
        request = make_request4openai(request_id, sentence, tag)
        request_list.append(request)
        request_count += 1
        content['request_id'] = f'req-{request_id}'
      else:
        print(f"Missing sentence or tag in content with request_id {request_id}")

      if request_count >= 50000:
        # save request list to a file
        batch_id = batch_count + 1
        batch_desc = f'batch-{batch_id}'
        batch_file = os.path.join(RESULT_DIR, FILTER_DIR, f'batch-{batch_id}.jsonl')
        logger.info(f'creating batch {batch_desc} with {request_count} requests')
        save_jsonl(request_list, batch_file)
        # ask batch to openai (upload the file and create batch run)
        batch_run = ask_batch_to_openai(batch_file, batch_desc, request_count)
        batch_run_list.append(batch_run)
        batch_count += 1
        request_list = list()
        request_count = 0

  if request_count > 0:
    # save request list to a file
    batch_id = batch_count + 1
    batch_desc = f'batch-{batch_id}'
    batch_file = os.path.join(RESULT_DIR, FILTER_DIR, f'batch-{batch_id}.jsonl')
    logger.info(f'creating batch {batch_desc} with {request_count} requests')
    save_jsonl(request_list, batch_file)
    # ask batch to openai (upload the file and create batch run)
    batch_run = ask_batch_to_openai(batch_file, batch_desc, request_count)
    batch_run_list.append(batch_run)
    batch_count += 1


  return batch_run_list

def ask_batch_to_openai(batch_file, batch_desc, request_count):
  batch_input_file = client.files.create(
    file=open(batch_file, "rb"),
    purpose="batch"
  )
  batch_input_file_id = batch_input_file.id

  batch_object = client.batches.create(
      input_file_id=batch_input_file_id,
      endpoint="/v1/chat/completions",
      completion_window="24h",
      metadata={
        "description": batch_desc
      }
  )
  batch_dict = vars(batch_object)
  batch_dict['request_counts'] = vars(batch_dict['request_counts'])

  batch_run = {
    'description': batch_desc,
    'file': batch_file,
    'input_file_id': batch_input_file_id,
    'request_count': request_count,
    'batch_id': batch_dict['id'],
    'batch': batch_dict,
  }
  return batch_run

def make_request4openai(request_id, sentence, tag):
  # {"custom_id": "request-1", "method": "POST", "url": "/v1/chat/completions",
  #  "body": {"model": "gpt-3.5-turbo-0125", "messages": [{"role": "system", "content": "You are a helpful assistant."}, {"role": "user", "content": "Hello world!"}], "max_tokens": 1000}}

  message_inst = f"Select the most appropriate category for the following sentence from the 9 tags. Just answer the tag without explanation.: '제안방법', '기술정의', '성능/효과', '후속연구', '이론/모형', '문제정의', '대상데이터', '데이터처리', '가설설정'. \
  Then, indicate whether your selection matches the original answer with Yes or No.\n"
  message_quest = f"Which of the 9 tags does the following sentence: \"{sentence}\" correspond to, and does it match the original answer: {tag}, Just answer with tag name and Yes/No"
  prompt = message_inst + message_quest

  messages = [{"role": "system", "content": "You are a helpful assistant."},
              {"role": "user", "content": prompt}]

  request = {
    "custom_id": f"req-{request_id}",
    "method": "POST",
    "url": "/v1/chat/completions",
    "body": {
      "model": GPT_MODEL,
      "messages": messages,
      "max_tokens": 100,
    }
  }

  return request


def check_all_batches(all_batch_run_list):
  """
    batch_run = {
    'description': batch_desc,
    'file': batch_file,
    'input_file_id': batch_input_file_id,
    'request_count': request_count,
    'batch_id': batch_object['id'],
    'batch': batch_object,
  }
  """
  loop = True
  while loop:
    inprogress_count = 0
    for batch_run in all_batch_run_list:
      batch_status = batch_run['batch']['status']
      if batch_status in ['validating', 'in_progress', 'finalizing', 'cancelling']:
        logger.info(f"checking batch run: {batch_run['description']} ...")
        batch_id = batch_run['batch_id']
        batch_object = client.batches.retrieve(batch_id)
        batch_dict = vars(batch_object)
        batch_dict['request_counts'] = vars(batch_dict['request_counts'])
        batch_run['batch'] = batch_dict
        batch_status = batch_run['batch']['status']
        logger.info(f"{batch_run['description']}: {batch_status}")

        if batch_status in ['validating', 'in_progress', 'finalizing', 'cancelling']:
          inprogress_count += 1
        else:
          output_file_id = batch_run['batch']['output_file_id']
          if output_file_id:
            output_file_response = client.files.content(output_file_id)
            path = os.path.join(RESULT_DIR, FILTER_DIR, f"{batch_run['description']}-output.jsonl")
            save_text(output_file_response.text, path)
            logger.info(f"{batch_run['description']}: output file saved to {path}")

          error_file_id = batch_run['batch']['error_file_id']
          if error_file_id:
            error_file_response = client.files.content(error_file_id)
            path = os.path.join(RESULT_DIR, FILTER_DIR, f"{batch_run['description']}-error.jsonl")
            save_text(error_file_response.text, path)
            logger.info(f"{batch_run['description']}: error file saved to {path}")

    if inprogress_count > 0:
      logger.info(f"{inprogress_count} batch runs are in progress among {len(all_batch_run_list)}")
      logger.info("sleeping for 30 minutes (1800 secs) ...")
      time.sleep(1800.0)
      logger.info("awakening from sleep ...")
    else:
      logger.info(f"{len(all_batch_run_list)} batch runs all finished.")
      logger.info(json.dumps(all_batch_run_list, indent=2, ensure_ascii=False))
      loop = False
  return all_batch_run_list


## load data ########################################################################


## general utils ##############################################################
def save_jsonl(data, path):
  with open(path, 'w', encoding='utf-8') as f:
    for item in data:
      f.write(json.dumps(item, ensure_ascii=False))
      f.write('\n')


def save_json(data, path):
  with open(path, 'w', encoding='utf-8') as f:
    f.write(json.dumps(data, indent=2, ensure_ascii=False))


def save_text(text, path):
  with open(path, 'w', encoding='utf-8') as f:
    f.write(text)


if __name__ == '__main__':
  main()
